package flowervisiting;

import java.io.File;

import jxl.Workbook;

public class GetTheData {
	
	Workbook workbook = Workbook.getWorkbook(new File("/Users/bridgitdavis/Documents/workspace/AlbanySample.xls"));
	 
	
	workbook.close();


}
