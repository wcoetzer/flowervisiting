/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Package
///////////////
package flowervisiting;


// Imports
///////////////
import com.hp.hpl.jena.ontology.*;
import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.shared.PrefixMapping;
import com.hp.hpl.jena.util.iterator.Filter;

import java.io.*;
import java.util.*;
import java.io.File; 
import java.util.Date; 
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;




/**
 * <p>
 * Simple demonstration program to show how to list a hierarchy of classes. This
 * is not a complete solution to the problem (sub-classes of restrictions, for example,
 * are not shown).  It is intended only to be illustrative of the general approach.
 * </p>
 */
public class ClassHierarchyModified {
    // Constants
    //////////////////////////////////

    // Static variables
    //////////////////////////////////

    // Instance variables
    //////////////////////////////////

    protected OntModel m_model;
    private Map<AnonId,String> m_anonIDs = new HashMap<AnonId, String>();
    private int m_anonCount = 0;



    // Constructors
    //////////////////////////////////

    // External signature methods
    //////////////////////////////////
    
    
    
   

    /** Show the sub-class hierarchy encoded by the given model */
    public void showHierarchy( PrintStream out, OntModel m ) {
        // create an iterator over the root classes that are not anonymous class expressions
        Iterator<OntClass> i = m.listHierarchyRootClasses()
                      .filterDrop( new Filter<OntClass>() {
                                    @Override
                                    public boolean accept( OntClass r ) {
                                        return r.isAnon();
                                    }} );

        while (i.hasNext()) {
            showClass( out, i.next(), new ArrayList<OntClass>(), 0 );
        }
    }


    // Internal implementation methods
    //////////////////////////////////

    /** Present a class, then recurse down to the sub-classes.
     *  Use occurs check to prevent getting stuck in a loop
     */
    protected void showClass( PrintStream out, OntClass cls, List<OntClass> occurs, int depth ) {
        renderClassDescription( out, cls, depth );
        out.println();

        // recurse to the next level down
        if (cls.canAs( OntClass.class )  &&  !occurs.contains( cls )) {
            for (Iterator<OntClass> i = cls.listSubClasses( true );  i.hasNext(); ) {
                OntClass sub = i.next();

                // we push this expression on the occurs list before we recurse
                occurs.add( cls );
                showClass( out, sub, occurs, depth + 1 );
                occurs.remove( cls );
            }
        }
    }


    /**
     * <p>Render a description of the given class to the given output stream.</p>
     * @param out A print stream to write to
     * @param c The class to render
     */
    public void renderClassDescription( PrintStream out, OntClass c, int depth ) {
        indent( out, depth );

        if (c.isRestriction()) {
            renderRestriction( out, c.as( Restriction.class ) );
        }
        else {
            if (!c.isAnon()) {
                out.print( "Class " );
                renderURI( out, c.getModel(), c.getURI() );
                out.print( ' ' );
            }
            else {
                renderAnonymous( out, c, "class" );
            }
        }
    }

    /**
     * <p>Handle the case of rendering a restriction.</p>
     * @param out The print stream to write to
     * @param r The restriction to render
     */
    protected void renderRestriction( PrintStream out, Restriction r ) {
        if (!r.isAnon()) {
            out.print( "Restriction " );
            renderURI( out, r.getModel(), r.getURI() );
        }
        else {
            renderAnonymous( out, r, "restriction" );
        }

        out.print( " on property " );
        renderURI( out, r.getModel(), r.getOnProperty().getURI() );
    }

    /** Render a URI */
    protected void renderURI( PrintStream out, PrefixMapping prefixes, String uri ) {
        out.print( prefixes.shortForm( uri ) );
    }

    /** Render an anonymous class or restriction */
    protected void renderAnonymous( PrintStream out, Resource anon, String name ) {
        String anonID = m_anonIDs.get( anon.getId() );
        if (anonID == null) {
            anonID = "a-" + m_anonCount++;
            m_anonIDs.put( anon.getId(), anonID );
        }

        out.print( "Anonymous ");
        out.print( name );
        out.print( " with ID " );
        out.print( anonID );
    }

    /** Generate the indentation */
    protected void indent( PrintStream out, int depth ) {
        for (int i = 0;  i < depth; i++) {
            out.print( "  " );
        }
    }

	public static void writeOntModel(OntModel mDest,String destFile) {
		// write back the file
		try {
			File file = new File(destFile);
			OutputStream os = null;
			os=new FileOutputStream(file);
			mDest.write(os);
			os.close();
		} catch (FileNotFoundException e) {
			System.err.println("Error writing model to " + destFile);
		} catch (IOException e) {
			System.err.println("Error writing model to " + destFile);			
		}
	}
    //==============================================================================
    // Inner class definitions
    //==============================================================================
    public static final String baseUrifv = "http://cair.cs.ukzn.ac.za/fv#";
    public static final String baseUrifvm = "http://cair.cs.ukzn.ac.za/fvm#";

    public static void MakeAlbanyOccurrenceInstance(OntModel mo, String instanceName, String plant_taxon, String behavior, String insect_taxon, String event_date, String[][] table) {
    	
    	
    	
    	OntClass PVOcc = mo.getOntClass(baseUrifv+"PlantVisitorOccurrence");
    	Individual newPVOcc = PVOcc.createIndividual(baseUrifv+"plantvisitor_occurrence"+instanceName);
    	newPVOcc.addProperty(mo.getProperty(baseUrifv+ "behavior"), mo.createTypedLiteral(behavior));
    	
		
    	
    	OntClass HPOcc = mo.getOntClass(baseUrifv+"HostPlantOccurrence");
    	Individual newHPOcc = HPOcc.createIndividual(baseUrifv+"hostplant_occurrence"+instanceName);
    	
    	OntClass Evt = mo.getOntClass("http://purl.org/dc/dcmitype/Event");
    	Individual newEvt = Evt.createIndividual("http://purl.org/dc/dcmitype/Event"+instanceName);
    	newEvt.addProperty(mo.getProperty(baseUrifv + "eventDate"), mo.createTypedLiteral(event_date));
    	newPVOcc.addProperty(mo.getProperty("http://purl.org/dsw/" + "atEvent"), mo.getIndividual("http://purl.org/dc/dcmitype/Event"+instanceName));
    	newHPOcc.addProperty(mo.getProperty("http://purl.org/dsw/" + "atEvent"), mo.getIndividual("http://purl.org/dc/dcmitype/Event"+instanceName));
    	
    	OntClass PVOrg = mo.getOntClass(baseUrifv+"PlantVisitorIndividualOrganism");
    	Individual newPVOrg = PVOrg.createIndividual(baseUrifv+"plantvisitor_organism"+instanceName);
    	newPVOcc.addProperty(mo.getProperty("http://purl.org/dsw/"+ "occurrenceOf"), mo.getIndividual(baseUrifv+"plantvisitor_organism"+instanceName));
    	
    	OntClass HPOrg = mo.getOntClass(baseUrifv+"HostPlantIndividualOrganism");
    	Individual newHPOrg = HPOrg.createIndividual(baseUrifv+"hostplant_organism"+instanceName);
    	newHPOcc.addProperty(mo.getProperty("http://purl.org/dsw/"+ "occurrenceOf"), mo.getIndividual(baseUrifv+"hostplant_organism"+instanceName));
    	
    	OntClass PVInt = mo.getOntClass(baseUrifv+"PlantVisitationInteraction");
    	Individual newPVInt = PVInt.createIndividual(baseUrifv+"interaction"+instanceName);
    	
    	OntClass PVEvt = mo.getOntClass(baseUrifv+"PlantVisitationEvent");
    	Individual newPVEvt = PVEvt.createIndividual(baseUrifv+"pvevent"+instanceName);
	  	
      	//newPVEvt.addProperty(mo.getProperty(baseUrifv+"part_of"), mo.getIndividual(baseUrifv+"interaction"+instanceName));
       	newPVEvt.addProperty(mo.getProperty(baseUrifv+"part_of"), newPVInt);
        
    	
    	String b = "";
        
	  	/*for(int x = 0 ; x < 40 ; x++){
        	for(int y = 0 ; y < 2 ; y++){
        	
        		if(table[x][y].equals(behavior)){
        	    	  	 b = table[x][y+1];
        	    	  	 PVEvt = mo.getOntClass(baseUrifv+b);
        	    	  	 newPVEvt = PVEvt.createIndividual(baseUrifv+"pvevent"+instanceName);
        	    	  	 System.out.println(newPVEvt);
        	    	  	 break;
        	    	  	 
        		}
        		
        		if(b==""){
        			b="PlantVisitationEvent";
        		
        		}
        	 }
            }*/
          
            
            if (PVEvt == null)
            	PVEvt = mo.getOntClass(baseUrifv+b);
           System.out.println(baseUrifv+b);
           System.out.println(newPVEvt);
        	//Individual newPVEvt = PVEvt.createIndividual(baseUrifv+"pvevent"+instanceName);
        	 
        
            
        	System.out.println(baseUrifv + "part_of");
        	
        	OntClass PVRol = mo.getOntClass(baseUrifv+"PlantVisitorRole");
        	Individual newPVRol = PVRol.createIndividual(baseUrifv+"pvrole"+instanceName);
        	newPVRol.addProperty(mo.getProperty(baseUrifv+ "realized_in"), mo.getIndividual(baseUrifv+"interaction"+instanceName));
        	newPVRol.addProperty(mo.getProperty(baseUrifv+ "inheres_in"), mo.getIndividual(baseUrifv+"plantvisitor_organism"+instanceName));
        	
        	OntClass HPRol = mo.getOntClass(baseUrifv+"HostPlantRole");
        	Individual newHPRol = HPRol.createIndividual(baseUrifv+"hprole"+instanceName);
        	newHPRol.addProperty(mo.getProperty(baseUrifv+ "realized_in"), mo.getIndividual(baseUrifv+"interaction"+instanceName));
        	newHPRol.addProperty(mo.getProperty(baseUrifv+ "inheres_in"), mo.getIndividual(baseUrifv+"hostplant_organism"+instanceName));
        	
        	
        	OntClass HPIdt = mo.getOntClass("http://rs.tdwg.org/dwc/dwctype/"+"Identification");
        	Individual newHPIdt = HPIdt.createIndividual("http://rs.tdwg.org/dwc/dwctype/"+"hpident"+instanceName);
        	newHPOrg.addProperty(mo.getProperty("http://purl.org/dsw/"+ "hasIdentification"), mo.getIndividual("http://rs.tdwg.org/dwc/dwctype/"+"hpident"+instanceName));
        	
        	OntClass PVIdt = mo.getOntClass("http://rs.tdwg.org/dwc/dwctype/"+"Identification");
        	Individual newPVIdt = PVIdt.createIndividual("http://rs.tdwg.org/dwc/dwctype/"+"pvident"+instanceName);
        	newPVOrg.addProperty(mo.getProperty("http://purl.org/dsw/"+ "hasIdentification"), mo.getIndividual("http://rs.tdwg.org/dwc/dwctype/"+"pvident"+instanceName));
        	
        	OntClass HPTax = mo.getOntClass("http://rs.tdwg.org/dwc/dwctype/"+"Taxon");
        	Individual newHPTax = HPTax.createIndividual("http://rs.tdwg.org/dwc/dwctype/"+"hptaxon"+instanceName);
        	newHPTax.addProperty(mo.getProperty(baseUrifv+ "Name"), mo.createTypedLiteral(plant_taxon));
        	newHPTax.addProperty(mo.getProperty("http://purl.org/dsw/"+ "taxonOfId"), mo.getIndividual("http://rs.tdwg.org/dwc/dwctype/"+"hpident"+instanceName));
        	
        	
        	OntClass PVTax = mo.getOntClass("http://rs.tdwg.org/dwc/dwctype/"+"Taxon");
        	Individual newPVTax = PVTax.createIndividual("http://rs.tdwg.org/dwc/dwctype/"+"pvtaxon"+instanceName);
        	newPVTax.addProperty(mo.getProperty(baseUrifv+ "Name"), mo.createTypedLiteral(insect_taxon));
        	newPVTax.addProperty(mo.getProperty("http://purl.org/dsw/"+ "taxonOfId"), mo.getIndividual("http://rs.tdwg.org/dwc/dwctype/"+"pvident"+instanceName));
        	
        	
    	writeOntModel(mo, "../fv.owl");
    }
   
  
    
    
    public static void main( String[] args ) throws IOException {
    	
    	String [][] table = CreateArray.MakeArray("/Users/bridgitdavis/Documents/workspace/TDWG2013/BehaviourMappingAlbany.txt");
    	OntModel m = ModelFactory.createOntologyModel( OntModelSpec.OWL_MEM, null );

        // we have a local copy of the Pollinator ontology
        m.getDocumentManager().addAltEntry( "http://cair.cs.ukzn.ac.za/fv",
                                            "file:../fv.owl" );
        //m.getDocumentManager().addAltEntry( "http://cair.cs.ukzn.ac.za/fv.owl",
                                            //"file:../fv.owl" );
       
        m.read( "http://cair.cs.ukzn.ac.za/fv" );
        //String baseUri = "http://cair.cs.ukzn.ac.za/pollination.owl#";	
        /*System.out.println("Read Pollination ontology successfully");
        new ClassHierarchyModified().showHierarchy( System.out, m );*/
        		/*BufferedReader reader = null;
    			try {
    				reader = new BufferedReader(new FileReader("/Users/bridgitdavis/Documents/workspace/testE.txt"));
    			} catch (FileNotFoundException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}*/
    		    //String line = reader.readLine(); 
    			//String line = "4	Occurrence	Acacia caffra	Visiting flowers	Xylocopa scioensis	1986/12/09	Onverwacht, Oudtshoorn	-33.6263888888	22.2383333333	South Africa	Africa";

    			//while (line != null) {
    		        //List<String> items = Arrays.asList(line.split("\\s*\t\\s*"));
    		     
    		        	 //ClassHierarchyModified.MakeAlbanyOccurrenceInstance(m, "F"+items.get(0), items.get(2), items.get(3), items.get(4), items.get(5), table);
    		        	//System.out.println(line);
    		        //line = reader.readLine();
    		        
    		   // }
    		
    		    /*reader = null;
    			try {
    				reader = new BufferedReader(new FileReader("/Users/bridgitdavis/Documents/workspace/testD.txt"));
    			} catch (FileNotFoundException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    		    String line2 = reader.readLine(); 
    		    while (line2 != null) {
    		        List<String> items = Arrays.asList(line2.split("\\s*\t\\s*"));
    		     
    		        	ClassHierarchyModified.MakeAlbanyOccurrenceInstance(m, "D"+items.get(0), items.get(2), items.get(3), items.get(4), items.get(5), table);
    		        	System.out.println(line2);
    		        line2 = reader.readLine();
    		        
    		    }*/
    		        	
    		        	String filename = "/Users/bridgitdavis/Documents/workspace/AlbanySample.xls";
    		        	// Create an ArrayList to store the data read from excel sheet.
    		        	List sheetData = new ArrayList();
    		        	FileInputStream fis = null;
    		        	try{
    		        	fis = new FileInputStream(filename);
    		        	HSSFWorkbook workbook = new HSSFWorkbook(fis);
    		        	// Get the first sheet on the workbook.
    		        	HSSFSheet sheet = workbook.getSheetAt(0);
    		        	Iterator rows = sheet.rowIterator();
    		        	while (rows.hasNext()) {
    		        	HSSFRow row = (HSSFRow) rows.next();
    		        	Iterator cells = row.cellIterator();
    		        	List data = new ArrayList();
    		        	while (cells.hasNext()) {
    		        	HSSFCell cell = (HSSFCell) cells.next();
    		        	data.add(cell);
    		        	 }
    		        	sheetData.add(data);
    		        	
    		         	
    		        	ClassHierarchyModified.MakePVOccurrenceInstances(m, "Albany", data.get(0));
    		        	ClassHierarchyModified.MakeHPOccurrenceInstances(m, "Albany", data.get(0));
    		        	ClassHierarchyModified.MakePVEventInstances(m, "Albany", data.get(0), table, data.get(3));
    		        	ClassHierarchyModified.MakePVOrganismInstances(m, "Albany", data.get(0));
    		        	ClassHierarchyModified.MakeHPOrganismInstances(m, "Albany", data.get(0));
    		        	ClassHierarchyModified.MakeInteractionInstances(m, "Albany", data.get(0));
    		        	ClassHierarchyModified.MakePVRoleInstances(m, "Albany", data.get(0));
    		        	ClassHierarchyModified.MakeHPRoleInstances(m, "Albany", data.get(0));
    		        	
    		        	 }
    		        	
    		        	//showExcelData (sheetData);
    	    		      
    		        	
   		        	 } catch (IOException e) {
   		        	e.printStackTrace();
   		        	 } finally { 
   		        	 if (fis != null) {
   		        	 fis.close();
   		        	 }
   		        	 }
   
    		        	
    		        	
    		        	/*String filename2 = "/Users/bridgitdavis/Documents/workspace/IzikoSample.xls";
    		        	// Create an ArrayList to store the data read from excel sheet.
    		        	List sheetData2 = new ArrayList();
    		        	FileInputStream fis2 = null;
    		        	try{
    		        	fis2 = new FileInputStream(filename2);
    		        	HSSFWorkbook workbook = new HSSFWorkbook(fis2);
    		        	// Get the first sheet on the workbook.
    		        	HSSFSheet sheet = workbook.getSheetAt(0);
    		        	Iterator rows = sheet.rowIterator();
    		        	while (rows.hasNext()) {
    		        	HSSFRow row = (HSSFRow) rows.next();
    		        	Iterator cells = row.cellIterator();
    		        	List data = new ArrayList();
    		        	while (cells.hasNext()) {
    		        	HSSFCell cell = (HSSFCell) cells.next();
    		        	data.add(cell);
    		        	 }
    		        	sheetData2.add(data);
    		        	
    		        	ClassHierarchyModified.MakePVOccurrenceInstances(m, "Iziko", data.get(0));
    		        	ClassHierarchyModified.MakeHPOccurrenceInstances(m, "Iziko", data.get(0));
    		        	ClassHierarchyModified.MakePVEventInstances(m, "Iziko", data.get(0), table, data.get(3));
    		        	ClassHierarchyModified.MakePVOrganismInstances(m, "Iziko", data.get(0));
    		        	ClassHierarchyModified.MakeHPOrganismInstances(m, "Iziko", data.get(0));
    		        	ClassHierarchyModified.MakeInteractionInstances(m, "Iziko", data.get(0));
    		        	ClassHierarchyModified.MakePVRoleInstances(m, "Iziko", data.get(0));
    		        	ClassHierarchyModified.MakeHPRoleInstances(m, "Iziko", data.get(0));
    		        	
    		        	 }
    	    		      
    		        	
   		        	 } catch (IOException e) {
   		        	e.printStackTrace();
   		        	 } finally { 
   		        	 if (fis2 != null) {
   		        	 fis2.close();
   		        	 }
   		        	 }
   
   		        	String filename3 = "/Users/bridgitdavis/Documents/workspace/PPRISample.xls";
		        	// Create an ArrayList to store the data read from excel sheet.
		        	List sheetData3 = new ArrayList();
		        	FileInputStream fis3 = null;
		        	try{
		        	fis3 = new FileInputStream(filename3);
		        	HSSFWorkbook workbook = new HSSFWorkbook(fis3);
		        	// Get the first sheet on the workbook.
		        	HSSFSheet sheet = workbook.getSheetAt(0);
		        	Iterator rows = sheet.rowIterator();
		        	while (rows.hasNext()) {
		        	HSSFRow row = (HSSFRow) rows.next();
		        	Iterator cells = row.cellIterator();
		        	List data = new ArrayList();
		        	while (cells.hasNext()) {
		        	HSSFCell cell = (HSSFCell) cells.next();
		        	data.add(cell);
		        	 }
		        	sheetData3.add(data);
    		        	
    		        	ClassHierarchyModified.MakePVOccurrenceInstances(m, "ARC", data.get(0));
    		        	ClassHierarchyModified.MakeHPOccurrenceInstances(m, "ARC", data.get(0));
    		        	ClassHierarchyModified.MakePVEventInstances(m, "ARC", data.get(0), table, data.get(3));
    		        	ClassHierarchyModified.MakePVOrganismInstances(m, "ARC", data.get(0));
    		        	ClassHierarchyModified.MakeHPOrganismInstances(m, "ARC", data.get(0));
    		        	ClassHierarchyModified.MakeInteractionInstances(m, "ARC", data.get(0));
    		        	ClassHierarchyModified.MakePVRoleInstances(m, "ARC", data.get(0));
    		        	ClassHierarchyModified.MakeHPRoleInstances(m, "ARC", data.get(0));
    		        	
    		        	
    		        	//ClassHierarchyModified.test(m, data.get(3));
    		        	  
    		        	
    		        	 }
    		      
    		        	
    		        	 } catch (IOException e) {
    		        	e.printStackTrace();
    		        	 } finally { 
    		        	 if (fis3 != null) {
    		        	 fis3.close();
    		        	 }
    		        	 }*/
    		        	 
    		        	 
    		           System.out.println("done");   
    		        	 
   		        	 }  	 
    
    
    		        	
    		        	
    
   		        	 
   private static void showExcelData(List sheetData) {
    //
      // Iterates the data and print it out to the console.
    //
	 
	   
  for (int i = 0; i < sheetData.size(); i++) {
   List list = (List) sheetData.get(i);
   
  
   
  for (int j = 0; j < list.size(); j++) {
  Cell cell = (Cell) list.get(j);
  if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
  System.out.print(cell.getNumericCellValue());
  } else if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
  
	  System.out.print(cell.getRichStringCellValue());
  
  } else if (cell.getCellType() == Cell.CELL_TYPE_BOOLEAN) {
  System.out.print(cell.getBooleanCellValue());
  }
  if (j < list.size() - 1) {
  System.out.print(", ");
  }
  }
  System.out.println("");
  }
  }
   
   public static void MakePVOccurrenceInstances(OntModel mo, String db, Object Occurrence) {
	    double Occ = ((HSSFCell) Occurrence).getNumericCellValue();
	    OntClass PVOcc = mo.getOntClass(baseUrifv+"PlantVisitorOccurrence");
   		Individual newPVOcc = PVOcc.createIndividual(baseUrifv+db+"_plantvisitor_occurrence"+String.valueOf((int)Occ));
   		writeOntModel(mo, "../fv.owl");
   }
   
   public static void MakeHPOccurrenceInstances(OntModel mo, String db, Object Occurrence) {
	    double Occ = ((HSSFCell) Occurrence).getNumericCellValue();
	    OntClass HPOcc = mo.getOntClass(baseUrifv+"HostPlantOccurrence");
  		Individual newHPOcc = HPOcc.createIndividual(baseUrifv+db+"_hostplant_occurrence"+String.valueOf((int)Occ));
  		writeOntModel(mo, "../fv.owl");
  }
   
   public static void MakePVOrganismInstances(OntModel mo, String db, Object Occurrence) {
	   double Occ = ((HSSFCell) Occurrence).getNumericCellValue();
	   OntClass PVOrg = mo.getOntClass(baseUrifv+"PlantVisitorIndividualOrganism");
	   Individual newPVOrg = PVOrg.createIndividual(baseUrifv+db+"_plantvisitor_organism"+String.valueOf((int)Occ));
	   newPVOrg.addProperty(mo.getProperty("http://purl.org/dsw/"+ "hasOccurrence"), mo.getIndividual(baseUrifv+db+"_plantvisitor_occurrence"+String.valueOf((int)Occ)));
	   writeOntModel(mo, "../fv.owl");
   }

   public static void MakeHPOrganismInstances(OntModel mo, String db, Object Occurrence) {
	   double Occ = ((HSSFCell) Occurrence).getNumericCellValue();
	   OntClass HPOrg = mo.getOntClass(baseUrifv+"HostPlantIndividualOrganism");
	   Individual newHPOrg = HPOrg.createIndividual(baseUrifv+db+"_hostplant_organism"+String.valueOf((int)Occ));
	   newHPOrg.addProperty(mo.getProperty("http://purl.org/dsw/" + "hasOccurrence"), mo.getIndividual(baseUrifv+db+"_hostplant_occurrence"+String.valueOf((int)Occ)));
	   writeOntModel(mo, "../fv.owl");
   }
   
   public static void MakePVEventInstances(OntModel mo, String db, Object Occurrence, String[][] table, Object behavior) {
	    double Occ = ((HSSFCell) Occurrence).getNumericCellValue();
	    OntClass PVEvt = mo.getOntClass(baseUrifv+"PlantVisitationEvent");
    	Individual newPVEvt = null;
	  	String behav = ((HSSFCell) behavior).getRichStringCellValue().getString();
	  	String b = "";
	  	
	  	for(int x = 0 ; x < 40 ; x++){
    	for(int y = 0 ; y < 2 ; y++) {
    	
    		if(table[x][y].equals(behav)){
    	    	  	 b = table[x][y+1];
    	    	  	 PVEvt = mo.getOntClass(baseUrifv+b);
    	    	  	 newPVEvt = PVEvt.createIndividual(baseUrifv+db+"_pvevent"+String.valueOf((int)Occ));
    	    	  	 newPVEvt.addProperty(mo.getProperty(baseUrifv+ "behavior"), mo.createTypedLiteral(behav));
    	    	  	 break;	  	 
    		}
    		
    	 }
    	
         }
	  if(b==""){
		b="PlantVisitationEvent";
		PVEvt = mo.getOntClass(baseUrifv+b);
	  	newPVEvt = PVEvt.createIndividual(baseUrifv+db+"_pvevent"+String.valueOf((int)Occ));
	  	}
	  	writeOntModel(mo, "../fv.owl");
	
   }

   		public static void MakeInteractionInstances(OntModel mo, String db, Object Occurrence) {
   			double Occ = ((HSSFCell) Occurrence).getNumericCellValue();
   			OntClass PVInt = mo.getOntClass(baseUrifv+"PlantVisitationInteraction");
   			Individual newPVInt = PVInt.createIndividual(baseUrifv+db+"_interaction"+String.valueOf((int)Occ));
   			newPVInt.addProperty(mo.getProperty(baseUrifv+"has_part"), mo.getIndividual(baseUrifv+db+"_pvevent"+String.valueOf((int)Occ)));
   	        writeOntModel(mo, "../fv.owl");
   		}
   		
   		public static void MakePVRoleInstances(OntModel mo, String db, Object Occurrence) {
   			double Occ = ((HSSFCell) Occurrence).getNumericCellValue();
   			OntClass PVRol = mo.getOntClass(baseUrifv+"PlantVisitorRole");
   			Individual newPVRol = PVRol.createIndividual(baseUrifv+db+"_pvrole"+String.valueOf((int)Occ));
   			newPVRol.addProperty(mo.getProperty(baseUrifv+ "realized_in"), mo.getIndividual(baseUrifv+db+"_interaction"+String.valueOf((int)Occ)));
   			newPVRol.addProperty(mo.getProperty(baseUrifv+ "inheres_in"), mo.getIndividual(baseUrifv+db+"_plantvisitor_organism"+String.valueOf((int)Occ)));
   			writeOntModel(mo, "../fv.owl");
   		}
	
   		public static void MakeHPRoleInstances(OntModel mo, String db, Object Occurrence) {
   			double Occ = ((HSSFCell) Occurrence).getNumericCellValue();
   			OntClass HPRol = mo.getOntClass(baseUrifv+"HostPlantRole");
   			Individual newHPRol = HPRol.createIndividual(baseUrifv+db+"_hprole"+String.valueOf((int)Occ));
   			newHPRol.addProperty(mo.getProperty(baseUrifv+ "realized_in"), mo.getIndividual(baseUrifv+db+"_interaction"+String.valueOf((int)Occ)));
   			newHPRol.addProperty(mo.getProperty(baseUrifv+ "inheres_in"), mo.getIndividual(baseUrifv+db+"_hostplant_organism"+String.valueOf((int)Occ)));
   			writeOntModel(mo, "../fv.owl");
   		}
   
   
   
   
   
   
   
   

   public static void test(OntModel mo, Object Occurrence) {
	    //double Occ = ((HSSFCell) Occurrence).getNumericCellValue();
	    //OntClass HPOcc = mo.getOntClass(baseUrifv+"HostPlantOccurrence");
 		//Individual newHPOcc = HPOcc.createIndividual(baseUrifv+"hostplant_occurrence"+String.valueOf((int)Occ));
 		//writeOntModel(mo, "../fv.owl");
	   String behav = ((HSSFCell) Occurrence).getRichStringCellValue().getString();
	   System.out.println(behav);
 }
   
   
   
   
}


   


