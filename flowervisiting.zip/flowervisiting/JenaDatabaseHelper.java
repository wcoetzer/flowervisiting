package flowervisiting;

//Imports
///////////////
import com.hp.hpl.jena.ontology.*;
import com.hp.hpl.jena.query.Dataset;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.tdb.TDBFactory;

public class JenaDatabaseHelper {

private Model model;
private Dataset dataset;

public Model getJenaModel(){
if(model!=null){
    return model;
}
else{
    String directory = "JenaDatabase" ;
    try{
        dataset = TDBFactory.createDataset(directory);
        model = dataset.getNamedModel("file:../fvm.owl");
        return model;
    }catch(Exception e){
        System.out.println("Error when retrieving model: "+e.getMessage());
    }              
}
return null;
}

public void SaveAndCloseModel(){
if(model!=null && dataset!=null){
    model.commit();
    model.close();
    dataset.close();
}
}

public void ClearModel(){
if(model!=null && dataset!=null){
    model.removeAll();
    SaveAndCloseModel();
}
else{
	System.out.println("no model");
}
}
}