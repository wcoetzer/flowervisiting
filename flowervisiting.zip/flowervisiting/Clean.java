package flowervisiting;

public class Clean {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		JenaDatabaseHelper a = new JenaDatabaseHelper();
		a.getJenaModel();
		a.ClearModel();
	}

}
