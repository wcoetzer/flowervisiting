package flowervisiting;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class CreateArray {
	
	
	public static String[][] MakeArray(String fname) throws IOException {
		
		  BufferedReader reader= null;
			try {
				reader = new BufferedReader(new FileReader(fname));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		String[][] table = new String[40][2];
		String line = reader.readLine(); 
		  
		while (line != null) {
			  
			  for(int x = 0; x < 40; x++)
			  {
				  List<String> items = Arrays.asList(line.split("\\s*\t\\s*"));
				  for(int y = 0; y < 2; y++)
				  {
					  table[x][y] = items.get(y);
		        	}
				  line = reader.readLine();
			  }
	
			  for(int x = 0; x < 40; x++)
			  {
				  System.out.print((x)+"  ");
				  for(int y = 0; y < 2; y++)
				  {
					  System.out.print(table[x][y]+"  ");	
				  }
				System.out.println();
			  }
			  
		}
		return table;
		
	}

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		MakeArray("/Users/bridgitdavis/Documents/workspace/TDWG2013/BehaviourMappingAlbany.txt");

	}

}